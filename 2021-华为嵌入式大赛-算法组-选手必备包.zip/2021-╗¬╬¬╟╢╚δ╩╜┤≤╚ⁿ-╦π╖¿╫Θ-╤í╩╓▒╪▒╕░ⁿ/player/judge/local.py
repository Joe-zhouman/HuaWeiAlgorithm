import sys
from res import ResMgr
from work import Work
from case import CaseMgr

if __name__ == "__main__":
    ResMgr.ClearSolu()
    CaseMgr.Init()
    work = Work()